create
    definer = root@localhost procedure st()
begin
select name,age from cls;
select name,score from cls order by score desc;
end;

