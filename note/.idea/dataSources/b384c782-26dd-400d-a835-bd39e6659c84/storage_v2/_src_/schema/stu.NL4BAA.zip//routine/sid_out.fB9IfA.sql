create
    definer = root@localhost procedure sid_out(OUT sid int)
begin
select name from cls where id=sid;
end;

