create
    definer = root@localhost function score1(sid1 int, sid2 int) returns int
begin return (select score from cls where id = sid1) - (select score from cls where id = sid2); end;

