create
    definer = root@localhost procedure test(IN age int)
begin 
declare val int;
set val=1;
set val=val+age;
select val;
end;

