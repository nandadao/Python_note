create
    definer = root@localhost procedure get_age(IN uid int, OUT num int)
begin
declare val int;
select age from cls where id=uid into val;
set num=val;
end;

