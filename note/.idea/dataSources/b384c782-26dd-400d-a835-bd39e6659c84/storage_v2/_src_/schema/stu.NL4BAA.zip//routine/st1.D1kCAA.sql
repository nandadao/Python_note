create
    definer = root@localhost function st1() returns int
begin
update cls set score = 60 where name="Emma";
set @a=(select score from cls where name="Emma");
return @a;
end;

