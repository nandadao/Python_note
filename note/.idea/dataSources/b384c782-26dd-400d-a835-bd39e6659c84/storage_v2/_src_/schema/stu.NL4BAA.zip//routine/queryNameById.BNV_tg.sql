create
    definer = root@localhost function queryNameById(uid int) returns varchar(20)
begin
return (select name from cls where id = uid)
;
end;

