create view c1 as
select `stu`.`cls`.`name` AS `name`, `stu`.`cls`.`age` AS `age`, `stu`.`cls`.`score` AS `score`
from `stu`.`cls`
where (`stu`.`cls`.`score` >= 80);

