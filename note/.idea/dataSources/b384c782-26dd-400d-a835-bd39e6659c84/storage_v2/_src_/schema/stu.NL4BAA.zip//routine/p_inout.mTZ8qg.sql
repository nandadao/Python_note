create
    definer = root@localhost procedure p_inout(INOUT num int)
begin select num; set num = 100; select num; end;

